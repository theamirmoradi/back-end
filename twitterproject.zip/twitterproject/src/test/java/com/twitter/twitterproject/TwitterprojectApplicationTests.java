package com.twitter.twitterproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
