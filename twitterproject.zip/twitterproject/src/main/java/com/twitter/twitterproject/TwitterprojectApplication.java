package com.twitter.twitterproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwitterprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(TwitterprojectApplication.class, args);
    }

}
